- Map editor for 2d game types. This is more like a comon map editor becouse
you can modify lots of behavior things and the map will contain it.
- it is not finished (no grafics for animation,some bugs not fixed)